Drupal.locale = { 'pluralFormula': function ($n) { return Number((((($n%10)==1)&&(($n%100)!=11))?(0):((((($n%10)>=2)&&(($n%10)<=4))&&((($n%100)<10)||(($n%100)>=20)))?(1):2))); }, 'strings': {"":{"An AJAX HTTP error occurred.":"AJAX HTTP \u043f\u0430\u043c\u044b\u043b\u043a\u0430 \u0432\u044b\u043a\u0430\u043d\u0430\u043d\u043d\u044f.","HTTP Result Code: !status":"HTTP \u0432\u044b\u043d\u0456\u043a\u043e\u0432\u044b \u043a\u043e\u0434: !status","An AJAX HTTP request terminated abnormally.":"AJAX HTTP \u0437\u0430\u043f\u044b\u0442 \u043f\u0440\u044b\u043f\u044b\u043d\u0456\u045e\u0441\u044f \u043d\u0435\u0431\u044f\u0441\u043f\u0435\u0447\u043d\u0430.","Debugging information follows.":"\u0410\u0434\u043b\u0430\u0434\u0430\u0447\u043d\u0430\u044f \u0456\u043d\u0444\u0430\u0440\u043c\u0430\u0446\u044b\u044f \u043d\u0456\u0436\u044d\u0439.","Path: !uri":"\u0428\u043b\u044f\u0445: !uri","StatusText: !statusText":"\u0422\u044d\u043a\u0441\u0442 \u0441\u0442\u0430\u043d\u0443: !statusText","ResponseText: !responseText":"\u0422\u044d\u043a\u0441\u0442 \u0430\u0434\u043a\u0430\u0437\u0443: !responseText","ReadyState: !readyState":"\u0421\u0442\u0430\u043d \u0433\u0430\u0442\u043e\u045e\u043d\u0430\u0441\u0446\u0456: !readyState","Configure":"\u041a\u0430\u043d\u0444\u0456\u0433\u0443\u0440\u0430\u0432\u0430\u0446\u044c","Hide":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c","Show":"\u041f\u0430\u043a\u0430\u0437\u0430\u0446\u044c","(active tab)":"(\u0430\u043a\u0442\u044b\u045e\u043d\u044b \u0442\u0430\u0431)","Not restricted":"\u041d\u0435 \u0430\u0431\u043c\u0435\u0436\u0430\u0432\u0430\u043d\u0430","Restricted to certain pages":"\u0422\u043e\u043b\u044c\u043a\u0456 \u0434\u043b\u044f \u043f\u044d\u045e\u043d\u044b\u0445 \u0441\u0442\u0430\u0440\u043e\u043d\u0430\u043a","Not customizable":"\u041d\u0435 \u043c\u0430\u0433\u0447\u044b\u043c\u0430 \u043a\u0430\u0441\u0442\u0430\u043c\u0456\u0437\u0430\u0432\u0430\u0446\u044c","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"\u0417\u043c\u0435\u043d\u044b \u0434\u043b\u044f \u0433\u044d\u0442\u044b\u0445 \u0431\u043b\u043e\u043a\u0430\u045e \u0431\u0443\u0434\u0443\u0446\u044c \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u044b\u044f \u0442\u043e\u043b\u044c\u043a\u0456 \u043f\u0430\u0441\u043b\u044f \u0442\u0430\u0433\u043e \u044f\u043a \u0432\u044b \u043d\u0430\u0446\u0456\u0441\u043d\u0456\u0446\u0435 \u043d\u0430 \u043a\u043d\u043e\u043f\u043a\u0443 \u003Cem\u003E\u0417\u0430\u0445\u0430\u0432\u0430\u0446\u044c \u0431\u043b\u043e\u043a\u0456\u003C\/em\u003E","The block cannot be placed in this region.":"\u0411\u043b\u043e\u043a \u043d\u0435 \u043c\u043e\u0436\u0430 \u0431\u044b\u0446\u044c \u0440\u0430\u0437\u043c\u0435\u0448\u0447\u0430\u043d\u044b \u045e \u0433\u044d\u0442\u044b\u043c \u0440\u044d\u0433\u0456\u0451\u043d\u0435.","Re-order rows by numerical weight instead of dragging.":"\u041f\u0435\u0440\u0430\u0432\u044b\u0437\u043d\u0430\u0447\u044b \u0440\u0430\u0434\u043a\u0456 \u0432\u0430\u0433\u0456 \u043b\u0456\u0447\u0431\u0430\u043c\u0456 \u0437\u0430\u043c\u0435\u0441\u0442 \u043f\u0435\u0440\u0430\u043c\u044f\u0448\u0447\u044d\u043d\u043d\u044f.","Show row weights":"\u041f\u0430\u043a\u0430\u0437\u0430\u0446\u044c \u0432\u0430\u0433\u0443 \u0440\u0430\u0434\u043a\u0430","Hide row weights":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c \u0432\u0430\u0433\u0443 \u0440\u0430\u0434\u043a\u0430","Drag to re-order":"\u041f\u0435\u0440\u0430\u0446\u044f\u0433\u043d\u0443\u0446\u044c \u0434\u043b\u044f \u043f\u0430\u045e\u0442\u043e\u0440\u043d\u0430\u0433\u0430 \u0437\u0430\u043a\u0430\u0437\u0443","Changes made in this table will not be saved until the form is submitted.":"\u0417\u043c\u0435\u043d\u044b, \u0437\u0440\u043e\u0431\u043b\u0435\u043d\u044b\u044f \u045e \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b, \u043d\u0435 \u0431\u0443\u0434\u0443\u0446\u044c \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u044b\u044f \u0434\u0430 \u0430\u0434\u043f\u0440\u0430\u045e\u043a\u0456 \u0444\u043e\u0440\u043c\u044b.","Next":"\u041d\u0430\u0441\u0442\u0443\u043f\u043d\u044b","Status":"\u0421\u0442\u0430\u0442\u0443\u0441","Disabled":"\u0412\u044b\u043a\u043b\u044e\u0447\u0430\u043d\u0430","Enabled":"\u0410\u043a\u0442\u044b\u0432\u0430\u0432\u0430\u043d\u0430","Edit":"\u0420\u044d\u0434\u0430\u0433\u0430\u0432\u0430\u0446\u044c","Size":"\u041f\u0430\u043c\u0435\u0440","Search":"\u041f\u043e\u0448\u0443\u043a","none":"\u043d\u044f\u043c\u0430","Sunday":"\u043d\u044f\u0434\u0437\u0435\u043b\u044f","Monday":"\u043f\u0430\u043d\u044f\u0434\u0437\u0435\u043b\u0430\u043a","Tuesday":"\u0430\u045e\u0442\u043e\u0440\u0430\u043a","Wednesday":"\u0441\u0435\u0440\u0430\u0434\u0430","Thursday":"\u0447\u0430\u0446\u044c\u0432\u0435\u0440","Friday":"\u043f\u044f\u0442\u043d\u0456\u0446\u0430","Saturday":"\u0441\u0443\u0431\u043e\u0442\u0430","Add":"\u0414\u0430\u0434\u0430\u0446\u044c","Filename":"\u041d\u0430\u0437\u0432\u0430 \u0444\u0430\u0439\u043b\u0430","Upload":"\u0417\u0430\u0433\u0440\u0443\u0437\u0456\u0446\u044c","All":"\u0423\u0441\u0435","Done":"\u0417\u0440\u043e\u0431\u043b\u0435\u043d\u0430","N\/A":"\u041d\u0435 \u0434\u0430\u0441\u0442\u0443\u043f\u043d\u0430","OK":"OK","Prev":"\u041f\u0430\u043f\u044f\u0440\u044d\u0434\u043d\u0456","Mon":"\u043f\u0430\u043d","Tue":"\u0430\u045e\u0442","Wed":"\u0441\u0435\u0440","Thu":"\u0447\u0446\u0432","Fri":"\u043f\u044f\u0442","Sat":"\u0441\u0443\u0431","Sun":"\u043d\u044f\u0434\u0437","January":"\u0441\u0442\u0443\u0434\u0437\u0435\u043d\u044c","February":"\u043b\u044e\u0442\u044b","March":"\u0441\u0430\u043a\u0430\u0432\u0456\u043a","April":"\u043a\u0440\u0430\u0441\u0430\u0432\u0456\u043a","May":"\u041c\u0430\u044f","June":"\u0447\u044d\u0440\u0432\u0435\u043d\u044c","July":"\u043b\u0456\u043f\u0435\u043d\u044c","August":"\u0436\u043d\u0456\u0432\u0435\u043d\u044c","September":"\u0432\u0435\u0440\u0430\u0441\u0435\u043d\u044c","October":"\u043a\u0430\u0441\u0442\u0440\u044b\u0447\u043d\u0456\u043a","November":"\u043b\u0456\u0441\u0442\u0430\u043f\u0430\u0434","December":"\u0441\u043d\u0435\u0436\u0430\u043d\u044c","Hide summary":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c \u0440\u044d\u0437\u044e\u043c\u044d","Edit summary":"\u0420\u044d\u0434\u0430\u0433\u0430\u0432\u0430\u0446\u044c \u0440\u044d\u0437\u044e\u043c\u044d","Autocomplete popup":"\u0410\u045e\u0442\u0430\u043c\u0430\u0442\u044b\u0447\u043d\u0430\u044f popup \u043f\u0430\u0434\u043a\u0430\u0437\u043a\u0430","Searching for matches...":"\u041f\u043e\u0448\u0443\u043a \u0441\u0443\u043f\u0430\u0434\u0437\u0435\u043d\u043d\u044f\u045e...","Please wait...":"\u041a\u0430\u043b\u0456 \u043b\u0430\u0441\u043a\u0430, \u043f\u0430\u0447\u0430\u043a\u0430\u0439\u0446\u0435...","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"\u0410\u0431\u0440\u0430\u043d\u044b \u0444\u0430\u0439\u043b %filename \u043d\u044f \u043c\u043e\u0436\u0430 \u0431\u044b\u0446\u044c \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u043d\u044b. \u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b \u0444\u0430\u0439\u043b\u044b \u0442\u043e\u043b\u044c\u043a\u0456 \u0437 \u043d\u0430\u0441\u0442\u0443\u043f\u043d\u044b\u043c\u0456 \u043f\u0430\u0448\u044b\u0440\u044d\u043d\u043d\u044f\u043c\u0456: %extensions.","Not in menu":"\u041d\u044f\u043c\u0430 \u045e \u043c\u0435\u043d\u044e","Automatic alias":"\u0410\u045e\u0442\u0430\u043c\u0430\u0442\u044b\u0447\u043d\u044b \u0430\u0434\u0440\u0430\u0441","Alias: @alias":"\u0410\u043b\u0456\u0430\u0441: @alias","No alias":"\u041d\u044f\u043c\u0430 \u043f\u0441\u0435\u045e\u0434\u0430\u043d\u0456\u043c\u0430","New revision":"\u041d\u043e\u0432\u0430\u044f \u0432\u0435\u0440\u0441\u0456\u044f","No revision":"\u041d\u044f\u043c\u0430 \u0432\u0435\u0440\u0441\u0456\u0456","By @name on @date":"\u0417\u0440\u043e\u0431\u043b\u0435\u043d\u0430 @name \u045e @date","By @name":"\u041f\u0430 @name","Not published":"\u041d\u0435 \u0430\u043f\u0443\u0431\u043b\u0456\u043a\u0430\u0432\u0430\u043d\u044b","Select all rows in this table":"\u0412\u044b\u0431\u0440\u0430\u0446\u044c \u0443\u0441\u0435 \u0440\u0430\u0434\u043a\u0456 \u0437 \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b","Deselect all rows in this table":"\u0410\u0434\u043c\u044f\u043d\u0456\u0446\u0435 \u045e\u0441\u0435 \u0440\u0430\u0434\u043a\u0456 \u045e \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b","Requires a title":"\u041f\u0430\u0442\u0440\u0430\u0431\u0443\u0435 \u0437\u0430\u0433\u0430\u043b\u043e\u0432\u0430\u043a","Don\u0027t display post information":"\u041d\u0435 \u043f\u0430\u043a\u0430\u0437\u0432\u0430\u0446\u044c \u0456\u043d\u0444\u0430\u0440\u043c\u0430\u0446\u044b\u044e \u043f\u0430\u0441\u0442\u0430","This permission is inherited from the authenticated user role.":"\u0413\u044d\u0442\u044b\u044f \u0434\u0430\u0437\u0432\u043e\u043b\u044b \u0430\u0434\u043f\u0430\u0432\u044f\u0434\u0430\u044e\u0446\u044c \u0440\u043e\u043b\u0456 \u0022\u0437\u0430\u0440\u044d\u0433\u0456\u0441\u0442\u0440\u0430\u0432\u0430\u043d\u044b \u043a\u0430\u0440\u044b\u0441\u0442\u0430\u043b\u044c\u043d\u0456\u043a\u0022.","Allowed HTML tags":"\u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b\u044f HTML \u0442\u044d\u0433\u0456","Today":"\u0421\u0451\u043d\u043d\u044f","Jan":"\u0421\u0442\u0443\u0434","Feb":"\u041b\u044e\u0442","Mar":"\u0421\u0430\u043a","Apr":"\u041a\u0440\u0430\u0441","Jun":"\u0427\u044d\u0440","Jul":"\u041b\u0456\u043f","Aug":"\u0416\u043d","Sep":"\u0412\u0435\u0440","Oct":"\u041a\u0430\u0441","Nov":"\u041b\u0456\u0441","Dec":"\u0421\u043d\u0435\u0436","Su":"\u043d\u044f\u0434\u0437","Mo":"\u043f\u043d\u0434","Tu":"\u0430\u045e\u0442","We":"\u0441\u0440\u0434","Th":"\u0447\u0446\u0432","Fr":"\u043f\u0442\u043d","Sa":"\u0441\u0443\u0431","Shortcuts":"\u0425\u0443\u0442\u043a\u0456\u044f \u0441\u043f\u0430\u0441\u044b\u043b\u043a\u0456","mm\/dd\/yy":"\u043c\u043c\/\u0434\u0434\/\u0433\u0433","Only files with the following extensions are allowed: %files-allowed.":"\u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b\u044f \u0444\u0430\u0439\u043b\u044b \u0437 \u043d\u0430\u0441\u0442\u0443\u043f\u043d\u044b\u043c\u0456 \u043f\u0430\u0448\u044b\u0440\u044d\u043d\u043d\u044f\u043c\u0456: %files","Select":"\u0412\u044b\u0431\u0440\u0430\u0446\u044c","all":"\u0423\u0441\u0451"}} };;
(function($){
/**
 * Toggle the visibility of the scroll to top link.
 */
 
Drupal.behaviors.scroll_to_top = {
  attach: function (context, settings) {
	// append  back to top link top body if it is not
	var exist= jQuery('#back-top').length; // exist = 0 if element doesn't exist
	if(exist == 0){ // this test is for fixing the ajax bug 
		$("body").append("<p id='back-top'><a href='#top'><span id='button'></span><span id='link'>" + settings.scroll_to_top.label + "</span></a></p>");
	}
	// Preview function
	$("input").change(function () {
		// building the style for preview
		var style="<style>#scroll-to-top-prev-container #back-top-prev span#button-prev{ background-color:"+$("#edit-scroll-to-top-bg-color-out").val()+";} #scroll-to-top-prev-container #back-top-prev span#button-prev:hover{ background-color:"+$("#edit-scroll-to-top-bg-color-hover").val()+" }</style>"
		// building the html content of preview
		var html="<p id='back-top-prev' style='position:relative;'><a href='#top'><span id='button-prev'></span><span id='link'>";
		// if label enabled display it
		if($("#edit-scroll-to-top-display-text").attr('checked')){
		html+=$("#edit-scroll-to-top-label").val();
		}
		html+="</span></a></p>";
		// update the preview
		$("#scroll-to-top-prev-container").html(style+html);
	});
	$("#back-top").hide();
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});
	}
};
})(jQuery);
;
(function ($) {

Drupal.googleanalytics = {};

$(document).ready(function() {

  // Attach mousedown, keyup, touchstart events to document only and catch
  // clicks on all elements.
  $(document.body).bind("mousedown keyup touchstart", function(event) {

    // Catch the closest surrounding link of a clicked element.
    $(event.target).closest("a,area").each(function() {

      // Is the clicked URL internal?
      if (Drupal.googleanalytics.isInternal(this.href)) {
        // Skip 'click' tracking, if custom tracking events are bound.
        if ($(this).is('.colorbox') && (Drupal.settings.googleanalytics.trackColorbox)) {
          // Do nothing here. The custom event will handle all tracking.
          //console.info("Click on .colorbox item has been detected.");
        }
        // Is download tracking activated and the file extension configured for download tracking?
        else if (Drupal.settings.googleanalytics.trackDownload && Drupal.googleanalytics.isDownload(this.href)) {
          // Download link clicked.
          ga("send", {
            "hitType": "event",
            "eventCategory": "Downloads",
            "eventAction": Drupal.googleanalytics.getDownloadExtension(this.href).toUpperCase(),
            "eventLabel": Drupal.googleanalytics.getPageUrl(this.href),
            "transport": "beacon"
          });
        }
        else if (Drupal.googleanalytics.isInternalSpecial(this.href)) {
          // Keep the internal URL for Google Analytics website overlay intact.
          ga("send", {
            "hitType": "pageview",
            "page": Drupal.googleanalytics.getPageUrl(this.href),
            "transport": "beacon"
          });
        }
      }
      else {
        if (Drupal.settings.googleanalytics.trackMailto && $(this).is("a[href^='mailto:'],area[href^='mailto:']")) {
          // Mailto link clicked.
          ga("send", {
            "hitType": "event",
            "eventCategory": "Mails",
            "eventAction": "Click",
            "eventLabel": this.href.substring(7),
            "transport": "beacon"
          });
        }
        else if (Drupal.settings.googleanalytics.trackOutbound && this.href.match(/^\w+:\/\//i)) {
          if (Drupal.settings.googleanalytics.trackDomainMode !== 2 || (Drupal.settings.googleanalytics.trackDomainMode === 2 && !Drupal.googleanalytics.isCrossDomain(this.hostname, Drupal.settings.googleanalytics.trackCrossDomains))) {
            // External link clicked / No top-level cross domain clicked.
            ga("send", {
              "hitType": "event",
              "eventCategory": "Outbound links",
              "eventAction": "Click",
              "eventLabel": this.href,
              "transport": "beacon"
            });
          }
        }
      }
    });
  });

  // Track hash changes as unique pageviews, if this option has been enabled.
  if (Drupal.settings.googleanalytics.trackUrlFragments) {
    window.onhashchange = function() {
      ga("send", {
        "hitType": "pageview",
        "page": location.pathname + location.search + location.hash
      });
    };
  }

  // Colorbox: This event triggers when the transition has completed and the
  // newly loaded content has been revealed.
  if (Drupal.settings.googleanalytics.trackColorbox) {
    $(document).bind("cbox_complete", function () {
      var href = $.colorbox.element().attr("href");
      if (href) {
        ga("send", {
          "hitType": "pageview",
          "page": Drupal.googleanalytics.getPageUrl(href)
        });
      }
    });
  }

});

/**
 * Check whether the hostname is part of the cross domains or not.
 *
 * @param string hostname
 *   The hostname of the clicked URL.
 * @param array crossDomains
 *   All cross domain hostnames as JS array.
 *
 * @return boolean
 */
Drupal.googleanalytics.isCrossDomain = function (hostname, crossDomains) {
  /**
   * jQuery < 1.6.3 bug: $.inArray crushes IE6 and Chrome if second argument is
   * `null` or `undefined`, http://bugs.jquery.com/ticket/10076,
   * https://github.com/jquery/jquery/commit/a839af034db2bd934e4d4fa6758a3fed8de74174
   *
   * @todo: Remove/Refactor in D8
   */
  if (!crossDomains) {
    return false;
  }
  else {
    return $.inArray(hostname, crossDomains) > -1 ? true : false;
  }
};

/**
 * Check whether this is a download URL or not.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isDownload = function (url) {
  var isDownload = new RegExp("\\.(" + Drupal.settings.googleanalytics.trackDownloadExtensions + ")([\?#].*)?$", "i");
  return isDownload.test(url);
};

/**
 * Check whether this is an absolute internal URL or not.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isInternal = function (url) {
  var isInternal = new RegExp("^(https?):\/\/" + window.location.host, "i");
  return isInternal.test(url);
};

/**
 * Check whether this is a special URL or not.
 *
 * URL types:
 *  - gotwo.module /go/* links.
 *
 * @param string url
 *   The web url to check.
 *
 * @return boolean
 */
Drupal.googleanalytics.isInternalSpecial = function (url) {
  var isInternalSpecial = new RegExp("(\/go\/.*)$", "i");
  return isInternalSpecial.test(url);
};

/**
 * Extract the relative internal URL from an absolute internal URL.
 *
 * Examples:
 * - http://mydomain.com/node/1 -> /node/1
 * - http://example.com/foo/bar -> http://example.com/foo/bar
 *
 * @param string url
 *   The web url to check.
 *
 * @return string
 *   Internal website URL
 */
Drupal.googleanalytics.getPageUrl = function (url) {
  var extractInternalUrl = new RegExp("^(https?):\/\/" + window.location.host, "i");
  return url.replace(extractInternalUrl, '');
};

/**
 * Extract the download file extension from the URL.
 *
 * @param string url
 *   The web url to check.
 *
 * @return string
 *   The file extension of the passed url. e.g. "zip", "txt"
 */
Drupal.googleanalytics.getDownloadExtension = function (url) {
  var extractDownloadextension = new RegExp("\\.(" + Drupal.settings.googleanalytics.trackDownloadExtensions + ")([\?#].*)?$", "i");
  var extension = extractDownloadextension.exec(url);
  return (extension === null) ? '' : extension[1];
};

})(jQuery);
;
