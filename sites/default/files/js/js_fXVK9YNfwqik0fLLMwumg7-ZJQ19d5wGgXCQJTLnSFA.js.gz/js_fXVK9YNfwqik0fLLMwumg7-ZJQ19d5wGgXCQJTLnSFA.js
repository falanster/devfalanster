Drupal.locale = { 'pluralFormula': function ($n) { return Number((((($n%10)==1)&&(($n%100)!=11))?(0):((((($n%10)>=2)&&(($n%10)<=4))&&((($n%100)<10)||(($n%100)>=20)))?(1):2))); }, 'strings': {"":{"An AJAX HTTP error occurred.":"AJAX HTTP \u043f\u0430\u043c\u044b\u043b\u043a\u0430 \u0432\u044b\u043a\u0430\u043d\u0430\u043d\u043d\u044f.","HTTP Result Code: !status":"HTTP \u0432\u044b\u043d\u0456\u043a\u043e\u0432\u044b \u043a\u043e\u0434: !status","An AJAX HTTP request terminated abnormally.":"AJAX HTTP \u0437\u0430\u043f\u044b\u0442 \u043f\u0440\u044b\u043f\u044b\u043d\u0456\u045e\u0441\u044f \u043d\u0435\u0431\u044f\u0441\u043f\u0435\u0447\u043d\u0430.","Debugging information follows.":"\u0410\u0434\u043b\u0430\u0434\u0430\u0447\u043d\u0430\u044f \u0456\u043d\u0444\u0430\u0440\u043c\u0430\u0446\u044b\u044f \u043d\u0456\u0436\u044d\u0439.","Path: !uri":"\u0428\u043b\u044f\u0445: !uri","StatusText: !statusText":"\u0422\u044d\u043a\u0441\u0442 \u0441\u0442\u0430\u043d\u0443: !statusText","ResponseText: !responseText":"\u0422\u044d\u043a\u0441\u0442 \u0430\u0434\u043a\u0430\u0437\u0443: !responseText","ReadyState: !readyState":"\u0421\u0442\u0430\u043d \u0433\u0430\u0442\u043e\u045e\u043d\u0430\u0441\u0446\u0456: !readyState","Configure":"\u041a\u0430\u043d\u0444\u0456\u0433\u0443\u0440\u0430\u0432\u0430\u0446\u044c","Hide":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c","Show":"\u041f\u0430\u043a\u0430\u0437\u0430\u0446\u044c","(active tab)":"(\u0430\u043a\u0442\u044b\u045e\u043d\u044b \u0442\u0430\u0431)","Not restricted":"\u041d\u0435 \u0430\u0431\u043c\u0435\u0436\u0430\u0432\u0430\u043d\u0430","Restricted to certain pages":"\u0422\u043e\u043b\u044c\u043a\u0456 \u0434\u043b\u044f \u043f\u044d\u045e\u043d\u044b\u0445 \u0441\u0442\u0430\u0440\u043e\u043d\u0430\u043a","Not customizable":"\u041d\u0435 \u043c\u0430\u0433\u0447\u044b\u043c\u0430 \u043a\u0430\u0441\u0442\u0430\u043c\u0456\u0437\u0430\u0432\u0430\u0446\u044c","The changes to these blocks will not be saved until the \u003Cem\u003ESave blocks\u003C\/em\u003E button is clicked.":"\u0417\u043c\u0435\u043d\u044b \u0434\u043b\u044f \u0433\u044d\u0442\u044b\u0445 \u0431\u043b\u043e\u043a\u0430\u045e \u0431\u0443\u0434\u0443\u0446\u044c \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u044b\u044f \u0442\u043e\u043b\u044c\u043a\u0456 \u043f\u0430\u0441\u043b\u044f \u0442\u0430\u0433\u043e \u044f\u043a \u0432\u044b \u043d\u0430\u0446\u0456\u0441\u043d\u0456\u0446\u0435 \u043d\u0430 \u043a\u043d\u043e\u043f\u043a\u0443 \u003Cem\u003E\u0417\u0430\u0445\u0430\u0432\u0430\u0446\u044c \u0431\u043b\u043e\u043a\u0456\u003C\/em\u003E","The block cannot be placed in this region.":"\u0411\u043b\u043e\u043a \u043d\u0435 \u043c\u043e\u0436\u0430 \u0431\u044b\u0446\u044c \u0440\u0430\u0437\u043c\u0435\u0448\u0447\u0430\u043d\u044b \u045e \u0433\u044d\u0442\u044b\u043c \u0440\u044d\u0433\u0456\u0451\u043d\u0435.","Re-order rows by numerical weight instead of dragging.":"\u041f\u0435\u0440\u0430\u0432\u044b\u0437\u043d\u0430\u0447\u044b \u0440\u0430\u0434\u043a\u0456 \u0432\u0430\u0433\u0456 \u043b\u0456\u0447\u0431\u0430\u043c\u0456 \u0437\u0430\u043c\u0435\u0441\u0442 \u043f\u0435\u0440\u0430\u043c\u044f\u0448\u0447\u044d\u043d\u043d\u044f.","Show row weights":"\u041f\u0430\u043a\u0430\u0437\u0430\u0446\u044c \u0432\u0430\u0433\u0443 \u0440\u0430\u0434\u043a\u0430","Hide row weights":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c \u0432\u0430\u0433\u0443 \u0440\u0430\u0434\u043a\u0430","Drag to re-order":"\u041f\u0435\u0440\u0430\u0446\u044f\u0433\u043d\u0443\u0446\u044c \u0434\u043b\u044f \u043f\u0430\u045e\u0442\u043e\u0440\u043d\u0430\u0433\u0430 \u0437\u0430\u043a\u0430\u0437\u0443","Changes made in this table will not be saved until the form is submitted.":"\u0417\u043c\u0435\u043d\u044b, \u0437\u0440\u043e\u0431\u043b\u0435\u043d\u044b\u044f \u045e \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b, \u043d\u0435 \u0431\u0443\u0434\u0443\u0446\u044c \u0437\u0430\u0445\u0430\u0432\u0430\u043d\u044b\u044f \u0434\u0430 \u0430\u0434\u043f\u0440\u0430\u045e\u043a\u0456 \u0444\u043e\u0440\u043c\u044b.","Next":"\u041d\u0430\u0441\u0442\u0443\u043f\u043d\u044b","Status":"\u0421\u0442\u0430\u0442\u0443\u0441","Disabled":"\u0412\u044b\u043a\u043b\u044e\u0447\u0430\u043d\u0430","Enabled":"\u0410\u043a\u0442\u044b\u0432\u0430\u0432\u0430\u043d\u0430","Size":"\u041f\u0430\u043c\u0435\u0440","Search":"\u041f\u043e\u0448\u0443\u043a","none":"\u043d\u044f\u043c\u0430","Sunday":"\u043d\u044f\u0434\u0437\u0435\u043b\u044f","Monday":"\u043f\u0430\u043d\u044f\u0434\u0437\u0435\u043b\u0430\u043a","Tuesday":"\u0430\u045e\u0442\u043e\u0440\u0430\u043a","Wednesday":"\u0441\u0435\u0440\u0430\u0434\u0430","Thursday":"\u0447\u0430\u0446\u044c\u0432\u0435\u0440","Friday":"\u043f\u044f\u0442\u043d\u0456\u0446\u0430","Saturday":"\u0441\u0443\u0431\u043e\u0442\u0430","Add":"\u0414\u0430\u0434\u0430\u0446\u044c","Filename":"\u041d\u0430\u0437\u0432\u0430 \u0444\u0430\u0439\u043b\u0430","Upload":"\u0417\u0430\u0433\u0440\u0443\u0437\u0456\u0446\u044c","Done":"\u0417\u0440\u043e\u0431\u043b\u0435\u043d\u0430","N\/A":"\u041d\u0435 \u0434\u0430\u0441\u0442\u0443\u043f\u043d\u0430","OK":"OK","Prev":"\u041f\u0430\u043f\u044f\u0440\u044d\u0434\u043d\u0456","Mon":"\u043f\u0430\u043d","Tue":"\u0430\u045e\u0442","Wed":"\u0441\u0435\u0440","Thu":"\u0447\u0446\u0432","Fri":"\u043f\u044f\u0442","Sat":"\u0441\u0443\u0431","Sun":"\u043d\u044f\u0434\u0437","January":"\u0441\u0442\u0443\u0434\u0437\u0435\u043d\u044c","February":"\u043b\u044e\u0442\u044b","March":"\u0441\u0430\u043a\u0430\u0432\u0456\u043a","April":"\u043a\u0440\u0430\u0441\u0430\u0432\u0456\u043a","May":"\u041c\u0430\u044f","June":"\u0447\u044d\u0440\u0432\u0435\u043d\u044c","July":"\u043b\u0456\u043f\u0435\u043d\u044c","August":"\u0436\u043d\u0456\u0432\u0435\u043d\u044c","September":"\u0432\u0435\u0440\u0430\u0441\u0435\u043d\u044c","October":"\u043a\u0430\u0441\u0442\u0440\u044b\u0447\u043d\u0456\u043a","November":"\u043b\u0456\u0441\u0442\u0430\u043f\u0430\u0434","December":"\u0441\u043d\u0435\u0436\u0430\u043d\u044c","Hide summary":"\u0421\u0445\u0430\u0432\u0430\u0446\u044c \u0440\u044d\u0437\u044e\u043c\u044d","Edit summary":"\u0420\u044d\u0434\u0430\u0433\u0430\u0432\u0430\u0446\u044c \u0440\u044d\u0437\u044e\u043c\u044d","Autocomplete popup":"\u0410\u045e\u0442\u0430\u043c\u0430\u0442\u044b\u0447\u043d\u0430\u044f popup \u043f\u0430\u0434\u043a\u0430\u0437\u043a\u0430","Searching for matches...":"\u041f\u043e\u0448\u0443\u043a \u0441\u0443\u043f\u0430\u0434\u0437\u0435\u043d\u043d\u044f\u045e...","Please wait...":"\u041a\u0430\u043b\u0456 \u043b\u0430\u0441\u043a\u0430, \u043f\u0430\u0447\u0430\u043a\u0430\u0439\u0446\u0435...","The selected file %filename cannot be uploaded. Only files with the following extensions are allowed: %extensions.":"\u0410\u0431\u0440\u0430\u043d\u044b \u0444\u0430\u0439\u043b %filename \u043d\u044f \u043c\u043e\u0436\u0430 \u0431\u044b\u0446\u044c \u0437\u0430\u0433\u0440\u0443\u0436\u0430\u043d\u044b. \u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b \u0444\u0430\u0439\u043b\u044b \u0442\u043e\u043b\u044c\u043a\u0456 \u0437 \u043d\u0430\u0441\u0442\u0443\u043f\u043d\u044b\u043c\u0456 \u043f\u0430\u0448\u044b\u0440\u044d\u043d\u043d\u044f\u043c\u0456: %extensions.","Not in menu":"\u041d\u044f\u043c\u0430 \u045e \u043c\u0435\u043d\u044e","Automatic alias":"\u0410\u045e\u0442\u0430\u043c\u0430\u0442\u044b\u0447\u043d\u044b \u0430\u0434\u0440\u0430\u0441","Alias: @alias":"\u0410\u043b\u0456\u0430\u0441: @alias","No alias":"\u041d\u044f\u043c\u0430 \u043f\u0441\u0435\u045e\u0434\u0430\u043d\u0456\u043c\u0430","New revision":"\u041d\u043e\u0432\u0430\u044f \u0432\u0435\u0440\u0441\u0456\u044f","No revision":"\u041d\u044f\u043c\u0430 \u0432\u0435\u0440\u0441\u0456\u0456","By @name on @date":"\u0417\u0440\u043e\u0431\u043b\u0435\u043d\u0430 @name \u045e @date","By @name":"\u041f\u0430 @name","Not published":"\u041d\u0435 \u0430\u043f\u0443\u0431\u043b\u0456\u043a\u0430\u0432\u0430\u043d\u044b","Select all rows in this table":"\u0412\u044b\u0431\u0440\u0430\u0446\u044c \u0443\u0441\u0435 \u0440\u0430\u0434\u043a\u0456 \u0437 \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b","Deselect all rows in this table":"\u0410\u0434\u043c\u044f\u043d\u0456\u0446\u0435 \u045e\u0441\u0435 \u0440\u0430\u0434\u043a\u0456 \u045e \u0433\u044d\u0442\u0430\u0439 \u0442\u0430\u0431\u043b\u0456\u0446\u044b","Requires a title":"\u041f\u0430\u0442\u0440\u0430\u0431\u0443\u0435 \u0437\u0430\u0433\u0430\u043b\u043e\u0432\u0430\u043a","Don\u0027t display post information":"\u041d\u0435 \u043f\u0430\u043a\u0430\u0437\u0432\u0430\u0446\u044c \u0456\u043d\u0444\u0430\u0440\u043c\u0430\u0446\u044b\u044e \u043f\u0430\u0441\u0442\u0430","This permission is inherited from the authenticated user role.":"\u0413\u044d\u0442\u044b\u044f \u0434\u0430\u0437\u0432\u043e\u043b\u044b \u0430\u0434\u043f\u0430\u0432\u044f\u0434\u0430\u044e\u0446\u044c \u0440\u043e\u043b\u0456 \u0022\u0437\u0430\u0440\u044d\u0433\u0456\u0441\u0442\u0440\u0430\u0432\u0430\u043d\u044b \u043a\u0430\u0440\u044b\u0441\u0442\u0430\u043b\u044c\u043d\u0456\u043a\u0022.","Allowed HTML tags":"\u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b\u044f HTML \u0442\u044d\u0433\u0456","Today":"\u0421\u0451\u043d\u043d\u044f","Jan":"\u0421\u0442\u0443\u0434","Feb":"\u041b\u044e\u0442","Mar":"\u0421\u0430\u043a","Apr":"\u041a\u0440\u0430\u0441","Jun":"\u0427\u044d\u0440","Jul":"\u041b\u0456\u043f","Aug":"\u0416\u043d","Sep":"\u0412\u0435\u0440","Oct":"\u041a\u0430\u0441","Nov":"\u041b\u0456\u0441","Dec":"\u0421\u043d\u0435\u0436","Su":"\u043d\u044f\u0434\u0437","Mo":"\u043f\u043d\u0434","Tu":"\u0430\u045e\u0442","We":"\u0441\u0440\u0434","Th":"\u0447\u0446\u0432","Fr":"\u043f\u0442\u043d","Sa":"\u0441\u0443\u0431","Shortcuts":"\u0425\u0443\u0442\u043a\u0456\u044f \u0441\u043f\u0430\u0441\u044b\u043b\u043a\u0456","mm\/dd\/yy":"\u043c\u043c\/\u0434\u0434\/\u0433\u0433","Only files with the following extensions are allowed: %files-allowed.":"\u0414\u0430\u0437\u0432\u043e\u043b\u0435\u043d\u044b\u044f \u0444\u0430\u0439\u043b\u044b \u0437 \u043d\u0430\u0441\u0442\u0443\u043f\u043d\u044b\u043c\u0456 \u043f\u0430\u0448\u044b\u0440\u044d\u043d\u043d\u044f\u043c\u0456: %files","Select":"\u0412\u044b\u0431\u0440\u0430\u0446\u044c","all":"\u0423\u0441\u0451"}} };;
(function($){
/**
 * Toggle the visibility of the scroll to top link.
 */
 
Drupal.behaviors.scroll_to_top = {
  attach: function (context, settings) {
	// append  back to top link top body if it is not
	var exist= jQuery('#back-top').length; // exist = 0 if element doesn't exist
	if(exist == 0){ // this test is for fixing the ajax bug 
		$("body").append("<p id='back-top'><a href='#top'><span id='button'></span><span id='link'>" + settings.scroll_to_top.label + "</span></a></p>");
	}
	// Preview function
	$("input").change(function () {
		// building the style for preview
		var style="<style>#scroll-to-top-prev-container #back-top-prev span#button-prev{ background-color:"+$("#edit-scroll-to-top-bg-color-out").val()+";} #scroll-to-top-prev-container #back-top-prev span#button-prev:hover{ background-color:"+$("#edit-scroll-to-top-bg-color-hover").val()+" }</style>"
		// building the html content of preview
		var html="<p id='back-top-prev' style='position:relative;'><a href='#top'><span id='button-prev'></span><span id='link'>";
		// if label enabled display it
		if($("#edit-scroll-to-top-display-text").attr('checked')){
		html+=$("#edit-scroll-to-top-label").val();
		}
		html+="</span></a></p>";
		// update the preview
		$("#scroll-to-top-prev-container").html(style+html);
	});
	$("#back-top").hide();
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$('#back-top').fadeIn();
			} else {
				$('#back-top').fadeOut();
			}
		});

		// scroll body to 0px on click
		$('#back-top a').click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});
	}
};
})(jQuery);
;
(function($) {

Drupal.admin = Drupal.admin || {};
Drupal.admin.behaviors = Drupal.admin.behaviors || {};

/**
 * @ingroup admin_behaviors
 * @{
 */

/**
 * Apply active trail highlighting based on current path.
 *
 * @todo Not limited to toolbar; move into core?
 */
Drupal.admin.behaviors.toolbarActiveTrail = function (context, settings, $adminMenu) {
  if (settings.admin_menu.toolbar && settings.admin_menu.toolbar.activeTrail) {
    $adminMenu.find('> div > ul > li > a[href="' + settings.admin_menu.toolbar.activeTrail + '"]').addClass('active-trail');
  }
};

/**
 * @} End of "ingroup admin_behaviors".
 */

Drupal.admin.behaviors.shorcutcollapsed = function (context, settings, $adminMenu) {

  // Create the dropdown base 
  $("<li class=\"label\"><a>"+Drupal.t('Shortcuts')+"</a></li>").prependTo("body.menu-render-collapsed div.toolbar-shortcuts ul"); 

}

Drupal.admin.behaviors.shorcutselect = function (context, settings, $adminMenu) {

  // Create the dropdown base
  $("<select id='shortcut-menu'/>").appendTo("body.menu-render-dropdown div.toolbar-shortcuts");
    
  // Create default option "Select"
  $("<option />", {
    "selected"  :  "selected",
    "value"     :  "",
    "text"      :  Drupal.t('Shortcuts')
  }).appendTo("body.menu-render-dropdown div.toolbar-shortcuts select");
    
  // Populate dropdown with menu items
  $("body.menu-render-dropdown div.toolbar-shortcuts a").each(function() {
    var el = $(this);
    $("<option />", {
      "value"   :  el.attr("href"),
      "text"    :  el.text()
    }).appendTo("body.menu-render-dropdown div.toolbar-shortcuts select");
    });
    
  $("body.menu-render-dropdown div.toolbar-shortcuts select").change(function() {
    window.location = $(this).find("option:selected").val();
  });
  
  $('body.menu-render-dropdown div.toolbar-shortcuts ul').remove();

};

})(jQuery);
;
(function ($) {

Drupal.behaviors.tableSelect = {
  attach: function (context, settings) {
    // Select the inner-most table in case of nested tables.
    $('th.select-all', context).closest('table').once('table-select', Drupal.tableSelect);
  }
};

Drupal.tableSelect = function () {
  // Do not add a "Select all" checkbox if there are no rows with checkboxes in the table
  if ($('td input:checkbox', this).length == 0) {
    return;
  }

  // Keep track of the table, which checkbox is checked and alias the settings.
  var table = this, checkboxes, lastChecked;
  var strings = { 'selectAll': Drupal.t('Select all rows in this table'), 'selectNone': Drupal.t('Deselect all rows in this table') };
  var updateSelectAll = function (state) {
    // Update table's select-all checkbox (and sticky header's if available).
    $(table).prev('table.sticky-header').andSelf().find('th.select-all input:checkbox').each(function() {
      $(this).attr('title', state ? strings.selectNone : strings.selectAll);
      this.checked = state;
    });
  };

  // Find all <th> with class select-all, and insert the check all checkbox.
  $('th.select-all', table).prepend($('<input type="checkbox" class="form-checkbox" />').attr('title', strings.selectAll)).click(function (event) {
    if ($(event.target).is('input:checkbox')) {
      // Loop through all checkboxes and set their state to the select all checkbox' state.
      checkboxes.each(function () {
        this.checked = event.target.checked;
        // Either add or remove the selected class based on the state of the check all checkbox.
        $(this).closest('tr').toggleClass('selected', this.checked);
      });
      // Update the title and the state of the check all box.
      updateSelectAll(event.target.checked);
    }
  });

  // For each of the checkboxes within the table that are not disabled.
  checkboxes = $('td input:checkbox:enabled', table).click(function (e) {
    // Either add or remove the selected class based on the state of the check all checkbox.
    $(this).closest('tr').toggleClass('selected', this.checked);

    // If this is a shift click, we need to highlight everything in the range.
    // Also make sure that we are actually checking checkboxes over a range and
    // that a checkbox has been checked or unchecked before.
    if (e.shiftKey && lastChecked && lastChecked != e.target) {
      // We use the checkbox's parent TR to do our range searching.
      Drupal.tableSelectRange($(e.target).closest('tr')[0], $(lastChecked).closest('tr')[0], e.target.checked);
    }

    // If all checkboxes are checked, make sure the select-all one is checked too, otherwise keep unchecked.
    updateSelectAll((checkboxes.length == $(checkboxes).filter(':checked').length));

    // Keep track of the last checked checkbox.
    lastChecked = e.target;
  });
};

Drupal.tableSelectRange = function (from, to, state) {
  // We determine the looping mode based on the the order of from and to.
  var mode = from.rowIndex > to.rowIndex ? 'previousSibling' : 'nextSibling';

  // Traverse through the sibling nodes.
  for (var i = from[mode]; i; i = i[mode]) {
    // Make sure that we're only dealing with elements.
    if (i.nodeType != 1) {
      continue;
    }

    // Either add or remove the selected class based on the state of the target checkbox.
    $(i).toggleClass('selected', state);
    $('input:checkbox', i).each(function () {
      this.checked = state;
    });

    if (to.nodeType) {
      // If we are at the end of the range, stop.
      if (i == to) {
        break;
      }
    }
    // A faster alternative to doing $(i).filter(to).length.
    else if ($.filter(to, [i]).r.length) {
      break;
    }
  }
};

})(jQuery);
;
(function ($) {

/**
 * Attaches sticky table headers.
 */
Drupal.behaviors.tableHeader = {
  attach: function (context, settings) {
    if (!$.support.positionFixed) {
      return;
    }

    $('table.sticky-enabled', context).once('tableheader', function () {
      $(this).data("drupal-tableheader", new Drupal.tableHeader(this));
    });
  }
};

/**
 * Constructor for the tableHeader object. Provides sticky table headers.
 *
 * @param table
 *   DOM object for the table to add a sticky header to.
 */
Drupal.tableHeader = function (table) {
  var self = this;

  this.originalTable = $(table);
  this.originalHeader = $(table).children('thead');
  this.originalHeaderCells = this.originalHeader.find('> tr > th');
  this.displayWeight = null;

  // React to columns change to avoid making checks in the scroll callback.
  this.originalTable.bind('columnschange', function (e, display) {
    // This will force header size to be calculated on scroll.
    self.widthCalculated = (self.displayWeight !== null && self.displayWeight === display);
    self.displayWeight = display;
  });

  // Clone the table header so it inherits original jQuery properties. Hide
  // the table to avoid a flash of the header clone upon page load.
  this.stickyTable = $('<table class="sticky-header"/>')
    .insertBefore(this.originalTable)
    .css({ position: 'fixed', top: '0px' });
  this.stickyHeader = this.originalHeader.clone(true)
    .hide()
    .appendTo(this.stickyTable);
  this.stickyHeaderCells = this.stickyHeader.find('> tr > th');

  this.originalTable.addClass('sticky-table');
  $(window)
    .bind('scroll.drupal-tableheader', $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    .bind('resize.drupal-tableheader', { calculateWidth: true }, $.proxy(this, 'eventhandlerRecalculateStickyHeader'))
    // Make sure the anchor being scrolled into view is not hidden beneath the
    // sticky table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceAnchor.drupal-tableheader', function () {
      window.scrollBy(0, -self.stickyTable.outerHeight());
    })
    // Make sure the element being focused is not hidden beneath the sticky
    // table header. Adjust the scrollTop if it does.
    .bind('drupalDisplaceFocus.drupal-tableheader', function (event) {
      if (self.stickyVisible && event.clientY < (self.stickyOffsetTop + self.stickyTable.outerHeight()) && event.$target.closest('sticky-header').length === 0) {
        window.scrollBy(0, -self.stickyTable.outerHeight());
      }
    })
    .triggerHandler('resize.drupal-tableheader');

  // We hid the header to avoid it showing up erroneously on page load;
  // we need to unhide it now so that it will show up when expected.
  this.stickyHeader.show();
};

/**
 * Event handler: recalculates position of the sticky table header.
 *
 * @param event
 *   Event being triggered.
 */
Drupal.tableHeader.prototype.eventhandlerRecalculateStickyHeader = function (event) {
  var self = this;
  var calculateWidth = event.data && event.data.calculateWidth;

  // Reset top position of sticky table headers to the current top offset.
  this.stickyOffsetTop = Drupal.settings.tableHeaderOffset ? eval(Drupal.settings.tableHeaderOffset + '()') : 0;
  this.stickyTable.css('top', this.stickyOffsetTop + 'px');

  // Save positioning data.
  var viewHeight = document.documentElement.scrollHeight || document.body.scrollHeight;
  if (calculateWidth || this.viewHeight !== viewHeight) {
    this.viewHeight = viewHeight;
    this.vPosition = this.originalTable.offset().top - 4 - this.stickyOffsetTop;
    this.hPosition = this.originalTable.offset().left;
    this.vLength = this.originalTable[0].clientHeight - 100;
    calculateWidth = true;
  }

  // Track horizontal positioning relative to the viewport and set visibility.
  var hScroll = document.documentElement.scrollLeft || document.body.scrollLeft;
  var vOffset = (document.documentElement.scrollTop || document.body.scrollTop) - this.vPosition;
  this.stickyVisible = vOffset > 0 && vOffset < this.vLength;
  this.stickyTable.css({ left: (-hScroll + this.hPosition) + 'px', visibility: this.stickyVisible ? 'visible' : 'hidden' });

  // Only perform expensive calculations if the sticky header is actually
  // visible or when forced.
  if (this.stickyVisible && (calculateWidth || !this.widthCalculated)) {
    this.widthCalculated = true;
    var $that = null;
    var $stickyCell = null;
    var display = null;
    var cellWidth = null;
    // Resize header and its cell widths.
    // Only apply width to visible table cells. This prevents the header from
    // displaying incorrectly when the sticky header is no longer visible.
    for (var i = 0, il = this.originalHeaderCells.length; i < il; i += 1) {
      $that = $(this.originalHeaderCells[i]);
      $stickyCell = this.stickyHeaderCells.eq($that.index());
      display = $that.css('display');
      if (display !== 'none') {
        cellWidth = $that.css('width');
        // Exception for IE7.
        if (cellWidth === 'auto') {
          cellWidth = $that[0].clientWidth + 'px';
        }
        $stickyCell.css({'width': cellWidth, 'display': display});
      }
      else {
        $stickyCell.css('display', 'none');
      }
    }
    this.stickyTable.css('width', this.originalTable.outerWidth());
  }
};

})(jQuery);
;
