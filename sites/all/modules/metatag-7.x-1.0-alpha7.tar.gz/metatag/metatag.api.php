<?php
/**
 * @file
 * API documentation for the Metatag module.
 */
